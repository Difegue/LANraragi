Once you've got a running LANraragi instance, you can basically dive right into the files to modify stuff to your needs.

### Deploying to a development server

Similarly to updating from a release, you can deploy your modified version to a remote server using _npm_.
```
npm run deploy [user]@[myserverip]:[remote_lanraragi_location]
```

**Hot Trick**: Adding the "DEV" keyword to the version number in index.pl will disable Github update nagging. _It's the little things_

### Code Writing
LRR is written in Perl CGI on the server-side, with basic JQuery on the clientside. No real frameworks are being used at this time. 

For PRs, as long as I can read it, it's fine! Which [might be easier said than done](https://www.perl.com/pub/2000/01/10PerlMyths.html/#Perl_looks_like_line_noise). 

Besides that, there's not much to say on the Perl side that doesn't fall into common sense: 
* [use strict; (and probably warnings too)](https://stackoverflow.com/questions/8023959/why-use-strict-and-warnings)
* Limit variables to the current block with the _my_ keyword.
* Comments

### Testing
The [Test::More](http://perldoc.perl.org/Test/More.html) module is used for testing the server-side part.  
The only subtlety to note here is that one needs to add the root codebase to @INC in order to be able to load the function files.

```
use Test::More tests => 4;

#Add root to @INC (we're in the tests folder, so the root is literally the previous folder)
use lib ".."; 

#What we're testing
require 'functions/functions_tags.pl';

#Test code goes here
```

### Codebase Architecture

```
- root/
    - content/ <- Empty folder, present as a default for adding archives to the app.
    - functions/ <- Core application code, split into files for each part of the app.
        - functions_config.pl <- This one in particular contains the default configuration values as well as Redis database settings.
    - img/ <- Media and thumbnail storage
    - js/ <- Core application JavaScript
    - styles/ <- Theme storage and core application CSS
    - templates/ <- HTML files used by the matching core pages. 
    - tests/ <- Tests. Ran by npm when executing the command npm test. 
    - tools/ <- Deployment files and scripting for Docker/Vagrant.
    - *.pl files <- Core pages:
        - ajax.pl <- API functions used by JavaScript for various small operations (metadata saving, thumbnail generation, etc.)
        - backup.pl <- Database Backup page.
        - config.pl <- Webapp Configuration page.
        - edit.pl <- Metadata Edition page.
        - index.pl <- Landing page, archive list. 
        - login.pl <- Login page.
        - random.pl <- "Give me a random archive" page.
        - reader.pl <- Archive Reader.
        - stats.pl <- Database Statistics page. 
        - tags.pl <- Mass Tagging page. 
        - upload.pl <- Archive Uploader. 


```