Getting all the files from the latest release and pasting them in the directory of the application should give you a painless update 95% of the time.  
Still, here are some steps/commands you can execute to make things easier.

## Updating a server on your local machine
```
rsync --exclude content -av [lanraragi_release_folder] [lanraragi_working_folder]
```
It doesn't really get any easier than this.

## Updating a remote server through SSH
From a LANraragi release folder, you can use npm to update a remote server:
```
npm run deploy [user]@[myserverip]:[remote_lanraragi_location]
```
This will automatically update the latest dependencies as well.

## Updating a Docker installation
You can open a bash prompt on the Docker container by using the command:
```
docker exec -it lanraragi bash
```
The old docker_ssh method is busted, check [#16 for more details.](https://github.com/Difegue/LANraragi/issues/16)

## Updating a Vagrant installation
You can open a remote console on the Vagrant VM by using the command: 
```
vagrant ssh
```
  
If the update isn't as painless as planned, consider backing up the database and reinstalling from scratch.  
_eyyo what can i say at least that works every time_