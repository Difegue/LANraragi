You can use the available Vagrantfile with [Vagrant](https://www.vagrantup.com/downloads.html) to deploy a virtual machine on your computer with LANraragi preinstalled.  
Download [the Vagrant setup](https://github.com/Difegue/LANraragi/raw/master/tools/VagrantSetup) somewhere, and whip out a terminal :
```
vagrant plugin install vagrant-vbguest
vagrant up
```
Once it's deployed(it takes a while to download everything), you'll have a /lanraragi folder, which syncs to an install located at [http://localhost:8080/lanraragi](http://localhost:8080/lanraragi) .  
You can use 
```
vagrant halt
```  
to stop the VM when you're done.  

The Vagrant setup automatically gets the latest revision from the git repo and grabs npm dependencies on its own. If the current development version has issues or the dependencies fail, please use the files from one of [the releases](https://github.com/Difegue/LANraragi/releases).