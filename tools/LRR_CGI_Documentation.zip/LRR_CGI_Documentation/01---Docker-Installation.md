A Docker image exists for deploying LANraragi installs to your machine easily without disrupting your already-existing web server setup.  
It also allows for easy installation on Windows/Mac !  

Download [the Docker setup](https://www.docker.com/products/docker) and install it. Once you're done, get the CLI out :  
```
docker run --name=lanraragi -p 8080:80 -v [YOUR_ARCHIVE_DIRECTORY]:/var/www/lanraragi/content difegue/lanraragi

```
The archive directory you have to specify in the command above will contain archives you either upload through the software or directly drop in. Use absolute paths.

Docker can only access drives you allow it to, so if you want to setup in a folder on another drive, be sure to give Docker access to it.  

Once your LANraragi container is loaded, you can access it at [http://localhost:8080/lanraragi](http://localhost:8080/lanraragi) .  
You can use the following commands to stop/start/remove the container(Removing it won't delete the archive directory you specified) : 
```
docker stop lanraragi
docker start lanraragi
docker rm lanraragi
```  

This whole setup gets a working LANraragi container from the Docker Hub, but you can build your own bleeding edge version by downloading [the Docker setup](https://github.com/Difegue/LANraragi/raw/master/tools/DockerSetup) and executing :
```
docker build -t whateverthefuckyouwant/lanraragi [FOLDER_CONTAINING_DOCKERFILE]
```  
This will get the latest revision from the git repo and grab npm dependencies on its own.  

Keep in mind that due to the magic of the _Docker Cloud™_, the container on the _latest_ tag is always based on the latest files from the git repo. For better or for worse.

Tags exist for major releases, so you can use those if the latest branch is too unstable.