![logo](https://raw.githubusercontent.com/Difegue/LANraragi/master/tools/logo.png)

Thank you for showing interest in this networked chinese comic reading software.  
Multiple installation solutions are available to you:  

1. [Docker Installation](https://github.com/Difegue/LANraragi/wiki/01-%7C-Docker-Installation)
2. [Vagrant Installation](https://github.com/Difegue/LANraragi/wiki/02-%7C-Vagrant-Installation)
3. [Manual Linux Installation](https://github.com/Difegue/LANraragi/wiki/03-%7C-Manual-Linux-Installation)

I recommend the Docker Installation for Windows/Mac users.  

## Installation under the Windows Subsystem for Linux (WSL)  
Also known as Bash on Ubuntu on Windows.  
You can install a working LRR instance on the WSL by following the Linux installation guide, with a few extra commands:  

* **Modify the Perl installation to use cpanm**. 
```
vi /usr/lib/x86_64-linux-gnu/perl/5.22.1/Config.pm
```  
Set ```dont_use_nlink``` to 'define'.   

* **Setup a symlink for bower to work properly**. 
```
ln -s /usr/bin/nodejs /usr/bin/node -f
```  

* **Start the services manually once installed**. 
```
service apache2 start
service redis-server start
```  

You'll have to do this last step every time you close and reopen the Bash for Windows terminal.

